importClass(Packages.com.tivoli.am.fim.trustserver.sts.utilities.IDMappingExtUtils);

function debugLog(s) {
    IDMappingExtUtils.traceString(s);
}

function jsToJavaArray(jsArray) {
    var javaArray = java.lang.reflect.Array.newInstance(java.lang.String, jsArray.length);
    for (var i = 0; i < jsArray.length; i++) {
            javaArray[i] = jsArray[i];
    }
    return javaArray;
}

function getInfomapUsername() {
	// get username from already authenticated user
	let result = context.get(Scope.REQUEST,
			"urn:ibm:security:asf:request:token:attribute", "username");
	debugLog("username from existing token: " + result);

	// if not there, try getting from session (e.g. UsernamePassword module)
	if (result == null) {
		result = context.get(Scope.SESSION,
				"urn:ibm:security:asf:response:token:attributes", "username");
		debugLog("username from session: " + result);
	}
	if (result != null) {
		// make it a javascript string - this prevents stringify issues later
		result = '' + result;
	}
	return result;
}

function sendJSONResponse(jObj) {
    page.setValue("/authsvc/authenticator/fido_infomap/jsonresponse.html");
    macros.put("@AUTHSVC_JSON_RESPONSE@", JSON.stringify(jObj));
    responseProcessed = true;
}

function sendErrorResponse(str) {
    page.setValue("/authsvc/authenticator/fido_infomap/error.html");
    macros.put("@ERROR_MSG@", str);
    responseProcessed = true;
}

function requestParam(key) {
    var value = context.get(Scope.REQUEST, "urn:ibm:security:asf:request:parameter", key);
    return (value == null) ? null : ''+value;
}

// used by both the registration and login infomaps
var responseProcessed = false;
var lfc = fido2ClientManager.getClient("myidp.ibm.com");
var result = false;
var loginErrorStr = null;


/*
 * Main body starts here
 */
// figure out what we are doing for this invocation
var cdj = requestParam("clientDataJSON");
// perform any specific action first
if (cdj != null) {
    var assertion = {
                    'type': requestParam("type"),
                    'id': requestParam("id"),
                    'rawId': requestParam("rawId"),
                    'response': {
                        'clientDataJSON': cdj,
                        'authenticatorData': requestParam("authenticatorData"),
                        'signature': requestParam("signature"),
                        'userHandle': requestParam("userHandle")
                    },
    };
    debugLog(''+JSON.stringify(assertion));
    var assertResult = JSON.parse(lfc.assertionResult(JSON.stringify(assertion)));
    debugLog(''+JSON.stringify(assertResult));
    var status = assertResult['status'];
    if (status == 'ok') {
        context.set(Scope.SESSION, "urn:ibm:security:asf:response:token:attributes", "username", assertResult.user.name);
        responseProcessed = true;
        result = true;
    } else {
        loginErrorStr = JSON.stringify(assertResult);
    }

} 

// default action is to show the login page
if (!responseProcessed) {
    //
    // note that we request a longer timeout (30 minutes) here for options to be used for
    // autofill because the login page might be idle for ages. The page will occassionally
    // refresh the challenge anyway, but this interrupts any in-progress attempt by the 
    // user to login, so we do not want to do that very often. 
    //
    // Our client uses seconds but the response will be in milliseconds as that is what 
    // WebAuthn uses. This ability to specify a custom timeout was added is ISVA 10.0.6.0.
    //
    let assertionOptionsStr = JSON.parse(lfc.assertionOptions(JSON.stringify({
        userVerification: "required",
        timeout: (30*60)
    })));
    var status = assertionOptionsStr['status'];
    if (status == 'ok') {
        let loginJSON = {
            username: getInfomapUsername(),
            autofillAssertionOptions: JSON.parse(''+assertionOptionsStr)
        };
        if (loginErrorStr != null) {
            loginJSON.lastError = loginErrorStr;
        }
        macros.put("@ESCAPED_FIDO_LOGIN_JSON@", JSON.stringify(loginJSON));
        macros.put("@FIDO_RP_ID@", assertionOptionsStr['rpId']);
        macros.put("@FIDO_TIMEOUT@", assertionOptionsStr['timeout'].toString());
        macros.put("@FIDO_CHALLENGE@", assertionOptionsStr['challenge']);
        macros.put('@FIDO_EXTENSIONS@', JSON.stringify(assertionOptionsStr['extensions']));
        macros.put("@FIDO_USER_ID@", assertionOptionsStr['userId'] == null ? "" : assertionOptionsStr['userId']);
        macros.put("@FIDO_STATUS@", assertionOptionsStr['status']);
        macros.put("@FIDO_ERROR_MESSAGE@", assertionOptionsStr['errorMessage']);
        macros.put("@FIDO_ALLOW_CREDENTIALS@", assertionOptionsStr['allowCredentials'] == null ? "[]" : JSON.stringify(assertionOptionsStr['allowCredentials']));
    } else {
        macros.put("@ERROR_MESSAGE@", assertionOptionsStr['errorMessage']);
    }
    page.setValue("/authsvc/authenticator/fido_infomap/login.html");
}


// final result - will be true if logging in
success.setValue(result);
