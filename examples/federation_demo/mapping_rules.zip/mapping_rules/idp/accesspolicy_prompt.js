importClass(Packages.com.ibm.security.access.policy.decision.Decision);
importClass(Packages.com.ibm.security.access.policy.decision.HtmlPageDenyDecisionHandler);
importClass(Packages.com.ibm.security.access.policy.decision.RedirectDenyDecisionHandler);
importClass(Packages.com.ibm.security.access.policy.decision.HtmlPageChallengeDecisionHandler);
importClass(Packages.com.ibm.security.access.policy.decision.RedirectChallengeDecisionHandler);
importPackage(Packages.com.tivoli.am.fim.trustserver.sts.utilities);

/*
 * Redirects a user to the authentication service, invoking the
 * username/password mechanism
 */
function getRedirectToAuthSvc() {
  var handler = new RedirectChallengeDecisionHandler();
  IDMappingExtUtils.traceString("rediect to authSvc");
  handler.setRedirectUri("https://www.myidp.ibm.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:password&Target=https://www.myidp.ibm.com/mga@ACTION@");
  IDMappingExtUtils.traceString("returning challenge");
  return handler;
}
var prompt_login_demo = true;
if(prompt_login_demo) {
  context.setDecision((function() {
	var request = context.getRequest();

	var user = context.getUser();
	if (user == null) {
	  IDMappingExtUtils.traceString("User isnt authenticated");
	  return Decision.challenge(getRedirectToAuthSvc());
	} else {
	  // The current HTTP request contains authentication request.
	  IDMappingExtUtils.traceString("Currently authenticated user: " + user);
	  var responseType = request.getParameter("response_type");
	  if (responseType == null) {
	  } else {
		// User is authenticated.
		var protocolContext = context.getProtocolContext();
		var authenticationRequest = protocolContext.getAuthenticationRequest();
		var authenticationContext = authenticationRequest.getAuthenticationContext();
		var promptVal = authenticationContext.getPrompt();

		IDMappingExtUtils.traceString("Prompt is: " + promptVal);
		if (promptVal != null && promptVal.contains("login")) {
		  return Decision.challenge(getRedirectToAuthSvc());
		} else {
		  IDMappingExtUtils.traceString("Allowed");
		  return Decision.allow();
		}
	  }
	}

	IDMappingExtUtils.traceString("Allowed");
	return Decision.allow();
  })());
}
