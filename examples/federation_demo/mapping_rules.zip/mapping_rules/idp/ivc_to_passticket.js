// mapping rule used for Passticket junctions example - mapping ivc to passticket

importPackage(Packages.com.tivoli.am.fim.trustserver.sts);
importPackage(Packages.com.tivoli.am.fim.trustserver.sts.uuser);
importPackage(Packages.com.tivoli.am.fim.trustserver.sts.utilities);

IDMappingExtUtils.traceString("ivc_to_passticket mapping rule called with stsuu: " + stsuu.toString());


stsuu.addAttribute(new Attribute("testattr_from_ivc_to_passticketmapping","urn:mytype", "myvalue_from_ivc_to_passticketmapping"));
